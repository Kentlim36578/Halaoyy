﻿using Microsoft.EntityFrameworkCore;
using BoholBusTracker.Core.Models;

namespace BoholBusTracker.Data.Context
{
    public class BoholBusTrackerDbContext : DbContext
    {
        public BoholBusTrackerDbContext(DbContextOptions<BoholBusTrackerDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Driver> Drivers { get; set; }
        public DbSet<Bus> Buses { get; set; }
        public DbSet<Route> Routes { get; set; }
        public DbSet<RouteStop> RouteStops { get; set; }
        public DbSet<GPSLocation> GPSLocations { get; set; }
        public DbSet<BusStatus> BusStatuses { get; set; }
        public DbSet<Core.Models.Schedule> Schedules { get; set; }
        public DbSet<Passenger> Passengers { get; set; }
        public DbSet<Ticket> Tickets { get; set; }
        public DbSet<Alert> Alerts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // User
            modelBuilder.Entity<User>().HasKey(u => u.UserId);
            modelBuilder.Entity<User>().Property(u => u.Username).IsRequired().HasMaxLength(100);
            modelBuilder.Entity<User>().Property(u => u.Email).IsRequired().HasMaxLength(255);
            modelBuilder.Entity<User>().HasIndex(u => u.Username).IsUnique();
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();

            // Driver
            modelBuilder.Entity<Driver>().HasKey(d => d.DriverId);
            modelBuilder.Entity<Driver>().HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId).OnDelete(DeleteBehavior.Restrict);

            // Bus
            modelBuilder.Entity<Bus>().HasKey(b => b.BusId);
            modelBuilder.Entity<Bus>().Property(b => b.PlateNumber).IsRequired().HasMaxLength(50);
            modelBuilder.Entity<Bus>().HasIndex(b => b.PlateNumber).IsUnique();
            modelBuilder.Entity<Bus>().HasOne(b => b.CurrentDriver).WithMany(d => d.AssignedBuses)
                .HasForeignKey(b => b.CurrentDriverId).OnDelete(DeleteBehavior.SetNull);

            // Route
            modelBuilder.Entity<Route>().HasKey(r => r.RouteId);
            modelBuilder.Entity<Route>().Property(r => r.RouteName).IsRequired().HasMaxLength(100);

            // RouteStop
            modelBuilder.Entity<RouteStop>().HasKey(rs => rs.StopId);
            modelBuilder.Entity<RouteStop>().HasOne(rs => rs.Route).WithMany(r => r.Stops)
                .HasForeignKey(rs => rs.RouteId).OnDelete(DeleteBehavior.Cascade);

            // GPSLocation
            modelBuilder.Entity<GPSLocation>().HasKey(g => g.LocationId);
            modelBuilder.Entity<GPSLocation>().HasOne(g => g.Bus).WithMany(b => b.GPSLocations)
                .HasForeignKey(g => g.BusId).OnDelete(DeleteBehavior.Cascade);

            // BusStatus
            modelBuilder.Entity<BusStatus>().HasKey(bs => bs.StatusId);
            // Add any additional configuration for BusStatus here if needed
        } // <-- This closes the OnModelCreating method
    } // <-- This closes the BoholBusTrackerDbContext class
}
