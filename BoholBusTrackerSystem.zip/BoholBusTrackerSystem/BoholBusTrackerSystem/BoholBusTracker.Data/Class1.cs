﻿namespace BoholBusTracker.Data
{
    public class Class1
    {

    }
}
