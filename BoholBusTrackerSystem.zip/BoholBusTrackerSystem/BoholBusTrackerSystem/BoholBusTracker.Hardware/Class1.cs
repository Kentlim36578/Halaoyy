﻿namespace BoholBusTracker.Hardware
{
    public class Class1
    {

    }
}
