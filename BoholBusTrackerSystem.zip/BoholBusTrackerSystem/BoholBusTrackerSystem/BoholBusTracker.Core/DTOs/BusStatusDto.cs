﻿using BoholBusTracker.Core.Enums;

namespace BoholBusTracker.Core.DTOs
{
    public class BusStatusDto
    {
        public int StatusId { get; set; }
        public int BusId { get; set; }
        public BusStatusEnum Status { get; set; }
        public int? CurrentPassengers { get; set; }
        public int? NextStopId { get; set; }
        public string? Notes { get; set; }
        public DateTime RecordedAt { get; set; }
    }
}
