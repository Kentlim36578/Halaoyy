﻿namespace BoholBusTracker.Core.DTOs
{
    public class UpdateBusDto
    {
        public string BusName { get; set; } = string.Empty;
        public int Capacity { get; set; }
        public string Color { get; set; } = string.Empty;
        public bool IsActive { get; set; }
    }
}
