﻿namespace BoholBusTracker.Core.DTOs
{
    public class RouteStopDto
    {
        public int StopId { get; set; }
        public int RouteId { get; set; }
        public string StopName { get; set; } = string.Empty;
        public string Municipality { get; set; } = string.Empty;
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public int StopSequence { get; set; }
        public int EstimatedArrivalMinutes { get; set; }
        public bool IsTerminal { get; set; }
    }
}
