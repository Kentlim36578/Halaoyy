﻿using BoholBusTracker.Core.Enums;

namespace BoholBusTracker.Core.DTOs
{
    public class NearbyBusDto
    {
        public int BusId { get; set; }
        public string BusName { get; set; } = string.Empty;
        public string PlateNumber { get; set; } = string.Empty;
        public BusCompany Company { get; set; }
        public double CurrentLatitude { get; set; }
        public double CurrentLongitude { get; set; }
        public double DistanceFromUser { get; set; }
        public BusStatusEnum Status { get; set; }
        public int? CurrentPassengers { get; set; }
        public int Capacity { get; set; }
        public string CurrentRoute { get; set; } = string.Empty;
    }
}
