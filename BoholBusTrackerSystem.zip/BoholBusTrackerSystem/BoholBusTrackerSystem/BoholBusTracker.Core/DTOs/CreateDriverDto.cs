﻿namespace BoholBusTracker.Core.DTOs
{
    public class CreateDriverDto
    {
        public int UserId { get; set; }
        public string LicenseNumber { get; set; } = string.Empty;
        public DateTime LicenseExpiry { get; set; }
        public int YearsOfExperience { get; set; }
    }
}
