﻿namespace BoholBusTracker.Core.DTOs
{
    public class CreateRouteDto
    {
        public string RouteName { get; set; } = string.Empty;
        public string OriginCity { get; set; } = string.Empty;
        public string DestinationCity { get; set; } = string.Empty;
        public double Distance { get; set; }
        public int EstimatedTravelTimeMinutes { get; set; }
        public decimal FareAmount { get; set; }
    }
}
