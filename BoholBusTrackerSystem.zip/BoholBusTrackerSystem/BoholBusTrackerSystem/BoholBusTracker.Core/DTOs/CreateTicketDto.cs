﻿namespace BoholBusTracker.Core.DTOs
{
    public class CreateTicketDto
    {
        public int PassengerId { get; set; }
        public int BusId { get; set; }
        public int ScheduleId { get; set; }
        public int RouteId { get; set; }
        public int SeatNumber { get; set; }
        public decimal Price { get; set; }
    }
}
