﻿using BoholBusTracker.Core.Enums;

namespace BoholBusTracker.Core.DTOs
{
    public class CreateBusStatusDto
    {
        public int BusId { get; set; }
        public BusStatusEnum Status { get; set; }
        public int? CurrentPassengers { get; set; }
        public int? NextStopId { get; set; }
        public string? Notes { get; set; }
    }
}
