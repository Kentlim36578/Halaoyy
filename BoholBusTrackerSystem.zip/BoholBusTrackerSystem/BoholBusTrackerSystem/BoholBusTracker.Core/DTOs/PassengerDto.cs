﻿namespace BoholBusTracker.Core.DTOs
{
    public class PassengerDto
    {
        public int PassengerId { get; set; }
        public int UserId { get; set; }
        public string EmergencyContact { get; set; } = string.Empty;
        public string EmergencyContactName { get; set; } = string.Empty;
        public bool IsVerified { get; set; }
    }
}
