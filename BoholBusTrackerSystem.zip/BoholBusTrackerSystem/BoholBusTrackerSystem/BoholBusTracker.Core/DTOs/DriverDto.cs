﻿namespace BoholBusTracker.Core.DTOs
{
    public class DriverDto
    {
        public int DriverId { get; set; }
        public int UserId { get; set; }
        public string LicenseNumber { get; set; } = string.Empty;
        public DateTime LicenseExpiry { get; set; }
        public string Experience { get; set; } = string.Empty;
        public int YearsOfExperience { get; set; }
        public bool IsActive { get; set; }
    }
}
