﻿namespace BoholBusTracker.Core.DTOs
{
    public class ETADto
    {
        public int BusId { get; set; }
        public int RouteId { get; set; }
        public int NextStopId { get; set; }
        public string NextStopName { get; set; } = string.Empty;
        public DateTime EstimatedArrivalTime { get; set; }
        public int RemainingMinutes { get; set; }
        public double RemainingDistance { get; set; }
    }
}
