﻿using BoholBusTracker.Core.Enums;

namespace BoholBusTracker.Core.DTOs
{
    public class BusDto
    {
        public int BusId { get; set; }
        public string PlateNumber { get; set; } = string.Empty;
        public string BusName { get; set; } = string.Empty;
        public BusCompany Company { get; set; }
        public int Capacity { get; set; }
        public string Manufacturer { get; set; } = string.Empty;
        public int YearManufactured { get; set; }
        public string Color { get; set; } = string.Empty;
        public bool IsActive { get; set; }
    }
}
