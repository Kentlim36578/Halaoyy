﻿namespace BoholBusTracker.Core.DTOs
{
    public class CreateScheduleDto
    {
        public int BusId { get; set; }
        public int RouteId { get; set; }
        public int? DriverId { get; set; }
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
    }
}
