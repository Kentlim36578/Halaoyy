﻿using BoholBusTracker.Core.Enums;

namespace BoholBusTracker.Core.DTOs
{
    public class DeviceStatusDto
    {
        public int DeviceId { get; set; }
        public DeviceType DeviceType { get; set; }
        public DeviceStatus Status { get; set; }
        public double BatteryLevel { get; set; }
        public DateTime LastUpdate { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
