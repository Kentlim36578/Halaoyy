﻿namespace BoholBusTracker.Core.DTOs
{
    public class TicketDto
    {
        public int TicketId { get; set; }
        public int PassengerId { get; set; }
        public int BusId { get; set; }
        public int ScheduleId { get; set; }
        public int RouteId { get; set; }
        public string TicketNumber { get; set; } = string.Empty;
        public int SeatNumber { get; set; }
        public decimal Price { get; set; }
        public bool IsUsed { get; set; }
        public DateTime PurchaseDate { get; set; }
    }
}
