﻿namespace BoholBusTracker.Core.DTOs
{
    public class CreatePassengerDto
    {
        public int UserId { get; set; }
        public string EmergencyContact { get; set; } = string.Empty;
        public string EmergencyContactName { get; set; } = string.Empty;
    }
}
