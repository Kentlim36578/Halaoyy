﻿using BoholBusTracker.Core.Enums;

namespace BoholBusTracker.Core.DTOs
{
    public class AlertDto
    {
        public int AlertId { get; set; }
        public int BusId { get; set; }
        public AlertType AlertType { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public bool IsResolved { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
