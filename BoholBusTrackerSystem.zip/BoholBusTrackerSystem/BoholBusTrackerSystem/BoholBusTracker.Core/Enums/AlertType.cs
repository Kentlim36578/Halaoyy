﻿namespace BoholBusTracker.Core.Enums
{
    public enum AlertType
    {
        Information = 1,
        Warning = 2,
        Critical = 3,
        Delay = 4,
        Breakdown = 5
    }
}
