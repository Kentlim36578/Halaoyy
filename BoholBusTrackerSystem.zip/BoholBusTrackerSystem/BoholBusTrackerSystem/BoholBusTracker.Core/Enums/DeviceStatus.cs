﻿namespace BoholBusTracker.Core.Enums
{
    public enum DeviceStatus
    {
        Connected = 1,
        Disconnected = 2,
        LowBattery = 3,
        Error = 4
    }
}
