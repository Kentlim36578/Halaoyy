﻿namespace BoholBusTracker.Core.Enums
{
    public enum BusCompany
    {
        SouthernStar = 1,
        Ceres = 2
    }
}
