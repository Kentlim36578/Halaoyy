﻿namespace BoholBusTracker.Core.Enums
{
    public enum DeviceType
    {
        GPSTracker = 1,
        IoTTracker = 2,
        MobileGPS = 3,
        OBDGPS = 4
    }
}
