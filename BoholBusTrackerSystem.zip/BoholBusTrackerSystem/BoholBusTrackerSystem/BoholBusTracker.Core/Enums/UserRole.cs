﻿namespace BoholBusTracker.Core.Enums
{
    public enum UserRole
    {
        Admin = 1,
        Dispatcher = 2,
        Driver = 3,
        Passenger = 4
    }
}
