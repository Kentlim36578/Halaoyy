﻿namespace BoholBusTracker.Core.Enums
{
    public enum BusStatusEnum
    {
        OnTime = 1,
        Approaching = 2,
        Delayed = 3,
        Offline = 4
    }
}
