﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface ITrackingHubService
    {
        Task BroadcastBusLocationAsync(int busId, GPSLocationDto location);
        Task BroadcastBusStatusAsync(int busId, BusStatusDto status);
        Task BroadcastETAAsync(int busId, ETADto eta);
        Task BroadcastAlertAsync(int busId, AlertDto alert);
    }
}
