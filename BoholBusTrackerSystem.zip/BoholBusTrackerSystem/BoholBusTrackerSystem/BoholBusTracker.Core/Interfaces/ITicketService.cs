﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface ITicketService
    {
        Task<TicketDto> GetTicketByIdAsync(int ticketId);
        Task<IEnumerable<TicketDto>> GetAllTicketsAsync();
        Task<IEnumerable<TicketDto>> GetTicketsByPassengerAsync(int passengerId);
        Task<IEnumerable<TicketDto>> GetTicketsByBusAsync(int busId);
        Task<TicketDto> CreateTicketAsync(CreateTicketDto createTicketDto);
        Task<TicketDto> UpdateTicketAsync(int ticketId, CreateTicketDto updateTicketDto);
        Task DeleteTicketAsync(int ticketId);
        Task<TicketDto> MarkTicketAsUsedAsync(int ticketId);
    }
}
