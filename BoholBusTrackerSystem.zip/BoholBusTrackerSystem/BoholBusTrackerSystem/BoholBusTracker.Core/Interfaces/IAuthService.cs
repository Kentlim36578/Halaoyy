﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IAuthService
    {
        Task<AuthResponseDto> LoginAsync(LoginDto loginDto);
        Task<UserDto> RegisterAsync(CreateUserDto createUserDto);
        Task<AuthResponseDto> RefreshTokenAsync(string accessToken, string refreshToken);
        Task LogoutAsync(int userId);
        string GenerateAccessToken(UserDto user);
        string GenerateRefreshToken();
    }
}
