﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IGPSLocationService
    {
        Task<GPSLocationDto> GetLatestLocationAsync(int busId);
        Task<IEnumerable<GPSLocationDto>> GetLocationHistoryAsync(int busId, DateTime fromDate, DateTime toDate);
        Task<GPSLocationDto> RecordLocationAsync(GPSLocationDto gpsLocationDto);
        Task<IEnumerable<NearbyBusDto>> GetNearbyBusesAsync(double userLatitude, double userLongitude, double radiusKm = 5);
    }
}
