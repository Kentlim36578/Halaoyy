﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IPassengerService
    {
        Task<PassengerDto> GetPassengerByIdAsync(int passengerId);
        Task<IEnumerable<PassengerDto>> GetAllPassengersAsync();
        Task<PassengerDto> CreatePassengerAsync(CreatePassengerDto createPassengerDto);
        Task<PassengerDto> UpdatePassengerAsync(int passengerId, CreatePassengerDto updatePassengerDto);
        Task DeletePassengerAsync(int passengerId);
        Task<PassengerDto> GetPassengerByUserIdAsync(int userId);
    }
}
