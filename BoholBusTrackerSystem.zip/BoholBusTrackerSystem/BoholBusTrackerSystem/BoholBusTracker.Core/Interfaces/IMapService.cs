﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IMapService
    {
        Task<RouteDto> GetRouteAsync(double startLat, double startLng, double endLat, double endLng);
        Task<ETADto> CalculateETAAsync(int busId, int nextStopId);
        Task<RouteStopDto> GetNearestStopAsync(double latitude, double longitude);
        Task<double> CalculateDistanceAsync(double lat1, double lng1, double lat2, double lng2);
    }
}
