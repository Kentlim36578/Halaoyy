﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IBusStatusService
    {
        Task<BusStatusDto> GetLatestStatusAsync(int busId);
        Task<IEnumerable<BusStatusDto>> GetStatusHistoryAsync(int busId, DateTime fromDate, DateTime toDate);
        Task<BusStatusDto> UpdateBusStatusAsync(CreateBusStatusDto createStatusDto);
        Task<BusStatusDto> GetCurrentStatusAsync(int busId);
    }
}
