﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IValidationService
    {
        bool ValidateEmail(string email);
        bool ValidatePhoneNumber(string phoneNumber);
        bool ValidatePassword(string password);
        bool ValidateCoordinates(double latitude, double longitude);
        List<string> ValidateCreateUserDto(CreateUserDto dto);
        List<string> ValidateCreateBusDto(CreateBusDto dto);
        List<string> ValidateCreateRouteDto(CreateRouteDto dto);
    }
}
