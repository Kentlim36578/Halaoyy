﻿using BoholBusTracker.Core.Models;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<User> Users { get; }
        IRepository<Driver> Drivers { get; }
        IRepository<Bus> Buses { get; }
        IRepository<Route> Routes { get; }
        IRepository<RouteStop> RouteStops { get; }
        IRepository<GPSLocation> GPSLocations { get; }
        IRepository<BusStatus> BusStatuses { get; }
        IRepository<Schedule> Schedules { get; }
        IRepository<Passenger> Passengers { get; }
        IRepository<Ticket> Tickets { get; }
        IRepository<Alert> Alerts { get; }

        Task<int> SaveChangesAsync();
    }
}
