﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IDriverService
    {
        Task<DriverDto> GetDriverByIdAsync(int driverId);
        Task<IEnumerable<DriverDto>> GetAllDriversAsync();
        Task<DriverDto> CreateDriverAsync(CreateDriverDto createDriverDto);
        Task<DriverDto> UpdateDriverAsync(int driverId, CreateDriverDto updateDriverDto);
        Task DeleteDriverAsync(int driverId);
        Task<DriverDto> GetDriverByUserIdAsync(int userId);
    }
}
