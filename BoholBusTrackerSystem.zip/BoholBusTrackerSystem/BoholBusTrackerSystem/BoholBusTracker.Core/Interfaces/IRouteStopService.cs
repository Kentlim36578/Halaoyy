﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IRouteStopService
    {
        Task<RouteStopDto> GetStopByIdAsync(int stopId);
        Task<IEnumerable<RouteStopDto>> GetStopsByRouteAsync(int routeId);
        Task<RouteStopDto> CreateStopAsync(CreateRouteStopDto createStopDto);
        Task<RouteStopDto> UpdateStopAsync(int stopId, CreateRouteStopDto updateStopDto);
        Task DeleteStopAsync(int stopId);
    }
}
