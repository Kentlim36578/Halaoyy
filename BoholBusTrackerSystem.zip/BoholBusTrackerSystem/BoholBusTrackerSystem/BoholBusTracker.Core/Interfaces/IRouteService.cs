﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IRouteService
    {
        Task<RouteDto> GetRouteByIdAsync(int routeId);
        Task<IEnumerable<RouteDto>> GetAllRoutesAsync();
        Task<RouteDto> CreateRouteAsync(CreateRouteDto createRouteDto);
        Task<RouteDto> UpdateRouteAsync(int routeId, CreateRouteDto updateRouteDto);
        Task DeleteRouteAsync(int routeId);
        Task<IEnumerable<RouteStopDto>> GetRouteStopsAsync(int routeId);
    }
}
