﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IBusService
    {
        Task<BusDto> GetBusByIdAsync(int busId);
        Task<IEnumerable<BusDto>> GetAllBusesAsync();
        Task<IEnumerable<BusDto>> GetBusesByCompanyAsync(int company);
        Task<BusDto> CreateBusAsync(CreateBusDto createBusDto);
        Task<BusDto> UpdateBusAsync(int busId, UpdateBusDto updateBusDto);
        Task DeleteBusAsync(int busId);
        Task<BusDto> AssignDriverToBusAsync(int busId, int driverId);
    }
}
