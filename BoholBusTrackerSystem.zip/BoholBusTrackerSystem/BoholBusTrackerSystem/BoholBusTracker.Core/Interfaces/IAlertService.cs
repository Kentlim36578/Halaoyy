﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IAlertService
    {
        Task<AlertDto> GetAlertByIdAsync(int alertId);
        Task<IEnumerable<AlertDto>> GetAllAlertsAsync();
        Task<IEnumerable<AlertDto>> GetAlertsByBusAsync(int busId);
        Task<IEnumerable<AlertDto>> GetActiveAlertsAsync();
        Task<AlertDto> CreateAlertAsync(CreateAlertDto createAlertDto);
        Task<AlertDto> ResolveAlertAsync(int alertId);
        Task DeleteAlertAsync(int alertId);
    }
}
