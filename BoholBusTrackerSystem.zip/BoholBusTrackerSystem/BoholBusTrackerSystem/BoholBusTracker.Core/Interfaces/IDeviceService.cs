﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IDeviceService
    {
        Task ConnectDeviceAsync(string deviceId, string portName);
        Task DisconnectDeviceAsync(string deviceId);
        Task<GPSLocationDto> GetLocationAsync(string deviceId);
        Task<DeviceStatusDto> GetStatusAsync(string deviceId);
        Task<bool> IsConnectedAsync(string deviceId);
    }
}
