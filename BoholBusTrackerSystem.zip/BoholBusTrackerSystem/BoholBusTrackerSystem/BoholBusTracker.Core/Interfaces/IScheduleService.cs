﻿using BoholBusTracker.Core.DTOs;

namespace BoholBusTracker.Core.Interfaces
{
    public interface IScheduleService
    {
        Task<ScheduleDto> GetScheduleByIdAsync(int scheduleId);
        Task<IEnumerable<ScheduleDto>> GetAllSchedulesAsync();
        Task<IEnumerable<ScheduleDto>> GetSchedulesByBusAsync(int busId);
        Task<IEnumerable<ScheduleDto>> GetSchedulesByRouteAsync(int routeId);
        Task<ScheduleDto> CreateScheduleAsync(CreateScheduleDto createScheduleDto);
        Task<ScheduleDto> UpdateScheduleAsync(int scheduleId, CreateScheduleDto updateScheduleDto);
        Task DeleteScheduleAsync(int scheduleId);
    }
}
