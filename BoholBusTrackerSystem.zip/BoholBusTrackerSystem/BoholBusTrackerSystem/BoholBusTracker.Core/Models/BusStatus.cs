﻿using BoholBusTracker.Core.Enums;

namespace BoholBusTracker.Core.Models
{
    public class BusStatus
    {
        public int StatusId { get; set; }
        public int BusId { get; set; }
        public BusStatusEnum Status { get; set; }
        public int? CurrentPassengers { get; set; }
        public int? NextStopId { get; set; }
        public string? Notes { get; set; }
        public DateTime RecordedAt { get; set; }

        // Navigation
        public virtual Bus? Bus { get; set; }
        public virtual RouteStop? NextStop { get; set; }
    }
}
