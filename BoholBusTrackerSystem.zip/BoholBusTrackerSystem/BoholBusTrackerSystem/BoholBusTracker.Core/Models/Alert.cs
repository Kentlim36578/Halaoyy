﻿using BoholBusTracker.Core.Enums;

namespace BoholBusTracker.Core.Models
{
    public class Alert
    {
        public int AlertId { get; set; }
        public int BusId { get; set; }
        public AlertType AlertType { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public bool IsResolved { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ResolvedAt { get; set; }

        // Navigation
        public virtual Bus? Bus { get; set; }
    }
}
