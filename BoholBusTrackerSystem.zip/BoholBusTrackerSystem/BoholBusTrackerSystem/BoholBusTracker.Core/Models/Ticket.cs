﻿using BoholBusTracker.Core.Models;

namespace BoholBusTracker.Core.Models
{
    public class Ticket
    {
        public int TicketId { get; set; }
        public int PassengerId { get; set; }
        public int BusId { get; set; }
        public int ScheduleId { get; set; }
        public int RouteId { get; set; }
        public string TicketNumber { get; set; } = string.Empty;
        public int SeatNumber { get; set; }
        public decimal Price { get; set; }
        public bool IsUsed { get; set; }
        public DateTime PurchaseDate { get; set; }
        public DateTime? UsedDate { get; set; }
        public DateTime CreatedAt { get; set; }

        // Navigation
        public virtual Passenger? Passenger { get; set; }
        public virtual Bus? Bus { get; set; }
        public virtual Schedule? Schedule { get; set; }
        public virtual Route? Route { get; set; }
    }
}
