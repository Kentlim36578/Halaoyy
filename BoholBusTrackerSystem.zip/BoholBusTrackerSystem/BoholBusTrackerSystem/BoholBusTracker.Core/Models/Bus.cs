﻿using BoholBusTracker.Core.Enums;
using System.Net.Sockets;

namespace BoholBusTracker.Core.Models
{
    public class Bus
    {
        public int BusId { get; set; }
        public string PlateNumber { get; set; } = string.Empty;
        public string BusName { get; set; } = string.Empty;
        public BusCompany Company { get; set; }
        public int Capacity { get; set; }
        public string Manufacturer { get; set; } = string.Empty;
        public int YearManufactured { get; set; }
        public string Color { get; set; } = string.Empty;
        public int? CurrentDriverId { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

        // Navigation
        public virtual Driver? CurrentDriver { get; set; }
        public virtual ICollection<Schedule>? Schedules { get; set; }
        public virtual ICollection<GPSLocation>? GPSLocations { get; set; }
        public virtual ICollection<BusStatus>? StatusHistory { get; set; }
        public virtual ICollection<Ticket>? Tickets { get; set; }
    }
}
