﻿namespace BoholBusTracker.Core.Models
{
    public class Route
    {
        public int RouteId { get; set; }
        public string RouteName { get; set; } = string.Empty;
        public string OriginCity { get; set; } = string.Empty;
        public string DestinationCity { get; set; } = string.Empty;
        public double Distance { get; set; }
        public int EstimatedTravelTimeMinutes { get; set; }
        public decimal FareAmount { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

        // Navigation
        public virtual ICollection<RouteStop>? Stops { get; set; }
        public virtual ICollection<Schedule>? Schedules { get; set; }
    }
}
