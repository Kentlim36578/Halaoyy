﻿namespace BoholBusTracker.Core.Models
{
    public class Driver
    {
        public int DriverId { get; set; }
        public int UserId { get; set; }
        public string LicenseNumber { get; set; } = string.Empty;
        public DateTime LicenseExpiry { get; set; }
        public string Experience { get; set; } = string.Empty;
        public int YearsOfExperience { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

        // Navigation
        public virtual User? User { get; set; }
        public virtual ICollection<Bus>? AssignedBuses { get; set; }
    }
}
