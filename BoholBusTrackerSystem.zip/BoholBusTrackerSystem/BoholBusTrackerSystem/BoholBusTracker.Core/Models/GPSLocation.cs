﻿namespace BoholBusTracker.Core.Models
{
    public class GPSLocation
    {
        public int LocationId { get; set; }
        public int BusId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double Altitude { get; set; }
        public double Speed { get; set; }
        public double Heading { get; set; }
        public int Accuracy { get; set; }
        public DateTime RecordedAt { get; set; }
        public string? Address { get; set; }

        // Navigation
        public virtual Bus? Bus { get; set; }
    }
}
