﻿using System.Net.Sockets;

namespace BoholBusTracker.Core.Models
{
    public class Passenger
    {
        public int PassengerId { get; set; }
        public int UserId { get; set; }
        public string EmergencyContact { get; set; } = string.Empty;
        public string EmergencyContactName { get; set; } = string.Empty;
        public bool IsVerified { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

        // Navigation
        public virtual User? User { get; set; }
        public virtual ICollection<Ticket>? Tickets { get; set; }
    }
}
