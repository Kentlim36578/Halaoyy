﻿namespace BoholBusTracker.MobileDLL
{
    public class Class1
    {

    }
}
