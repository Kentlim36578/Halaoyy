﻿namespace BoholBusTracker.Services
{
    public class Class1
    {

    }
}
